const locationSelect = document.getElementById('location');
const customLocation = document.getElementById('custom-location');
const customAddress = document.getElementById('custom-address');

locationSelect.addEventListener('change', () => {
  if (locationSelect.value === 'custom') {
    customLocation.style.display = 'block';
    customAddress.required = true;
  } else {
    customLocation.style.display = 'none';
    customAddress.required = false;
  }
});

const registrationForm = document.getElementById('registration-form');

registrationForm.addEventListener('submit', (event) => {
  // Prevent default form submission behavior
  event.preventDefault();

  // Get form data
  const location = locationSelect.value;
  const date = document.getElementById('date').value;
  const numTrees = document.getElementById('num-trees').value;
  let customAddr = '';
  if (location === 'custom') {
    customAddr = customAddress.value;
  }

  // Validate data (optional, can be improved)
  if (!location || !date || !numTrees) {
    alert('Please fill in all required fields.');
    return;
  }

  // Simulate form submission (replace with actual backend integration)
  const message = `You are registered for a tree planting event!\nLocation: ${location}${customAddr ? ' (' + customAddr + ')' : ''}\nDate: ${date}\nNumber of Trees: ${numTrees}`;
  alert(message);

  // Clear form after successful registration (optional)
  registrationForm.reset();
});